import { Link } from 'react-router-dom';
import('./Header.css');

function Header() {
   return (
      <header className="header page__header">
         <div className="header__container">
            <ul className="header__linkContainer">
               <li className="header__linkList">
                  <Link to={'/'} className="header__link ">
                     <div className="header__logoLink"></div>
                  </Link>
               </li>
               <li className="header__linkList">
                  <Link
                     to={'/movies'}
                     className="header__link header__link_type_movies"
                  >
                     Фильмы
                  </Link>
               </li>
               <li className="header__linkList">
                  <Link
                     to={'/saved-movies'}
                     className="header__link header__link_type_savedMovies"
                  >
                     Сохранённые фильмы
                  </Link>
               </li>
            </ul>
            <Link to={'/profile'} className="header__link">
               Аккаунт
            </Link>
         </div>
      </header>
   );
}

export default Header;

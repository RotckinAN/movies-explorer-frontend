function Movies() {
   return <h1>TEST Movies component</h1>;
}

export default Movies;

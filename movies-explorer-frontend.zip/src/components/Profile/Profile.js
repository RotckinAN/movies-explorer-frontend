import Header from '../Header/Header';

function Profile() {
   return <Header />;
}

export default Profile;

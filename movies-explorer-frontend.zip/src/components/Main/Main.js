function Main() {
   return <h1>TEST Main component</h1>;
}

export default Main;

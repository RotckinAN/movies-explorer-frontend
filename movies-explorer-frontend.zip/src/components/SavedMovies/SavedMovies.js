function SavedMovies() {
   return <h1>TEST SavedMovies component</h1>;
}

export default SavedMovies;
